print("start file", flush=True)
print("start loading libraries", flush=True)

import time
import dataset

print("finish import", flush=True)

print("prepare to sleep", flush=True)
time.sleep(1)
print("done", flush=True)
