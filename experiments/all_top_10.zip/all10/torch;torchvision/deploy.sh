#/bin/bash
docker system prune --force
docker image rm test
docker rm test
docker build --no-cache --progress=plain -t test . &> build$1.txt
docker system prune --force
echo descartes | sudo -S sh -c 'echo 1 >  /proc/sys/vm/drop_caches'
docker run --name test test
docker container logs test --timestamps --details &> run$1.txt
docker inspect test &> con$1.txt 
for run in 1 2 3 4 5
do
  docker rm test
  docker run --name test test
  docker container logs test --timestamps --details &> run"$1"_"$run".txt
  docker inspect test &> con"$1"_"$run".txt 
done
echo descartes | sudo -S sh -c 'echo 1 >  /proc/sys/vm/drop_caches'
