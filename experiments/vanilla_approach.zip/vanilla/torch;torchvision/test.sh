#/bin/bash
echo "start"
python3 -W ignore ./app.py
echo "stop"